package com.bankSystemDemo.service;

import com.bankSystemDemo.entity.User;

public interface UserService {
	
	public User registerUser(User user);

	User getUserByAccountNumber(String account_no);

	public void saveUser(User user);

	User updateUser(User user);
}
