package com.bankSystemDemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankSystemDemo.entity.User;

public interface UserRepository extends JpaRepository<User,Long>{

	User findByEmail(String email);

	User findByAccountAccountNumber(String accountNumber);
}
